package ibm.us.com.fashionx;

public interface MobileFirstListener {
    void onCurrent(MobileFirstWeather current);
}
