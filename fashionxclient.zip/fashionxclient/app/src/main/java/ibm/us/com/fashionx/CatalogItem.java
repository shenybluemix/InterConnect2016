package ibm.us.com.fashionx;

public class CatalogItem {
    String image;
    String placement;
    String title;
}
